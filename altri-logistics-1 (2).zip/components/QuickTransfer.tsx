
// Archivo eliminado - La funcionalidad ahora está integrada en TransferView.tsx
export const QuickTransfer = () => null;
